﻿import Travel1 from "./atikh-bana-Ycds6emp7BA-unsplash (1).jpg";
import Travel2 from "./luca-bravo-O453M2Liufs-unsplash.jpg";
import Travel3 from "./mesut-kaya-eOcyhe5-9sQ-unsplash.jpg";
import Travel4 from "./anete-lusina-rFKBUwLg_WQ-unsplash.jpg";

export { Travel1, Travel2, Travel3, Travel4 };
