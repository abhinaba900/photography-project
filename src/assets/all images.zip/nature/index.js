﻿import Nature1 from "./henry-be-IicyiaPYGGI-unsplash.jpg";
import Nature2 from "./qingbao-meng-01_igFr7hd4-unsplash.jpg";
import Nature3 from "./samsommer-vddccTqwal8-unsplash.jpg";
import Nature4 from "./urban-vintage-78A265wPiO4-unsplash.jpg";

export { Nature1, Nature2, Nature3, Nature4 }