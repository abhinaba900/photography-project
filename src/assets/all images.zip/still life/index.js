﻿import StillLife1 from "./debby-hudson-FO4gzqI2t84-unsplash.jpg";
import StillLife2 from "./florencia-potter-cCV85jQ_1n4-unsplash.jpg";
import StillLife3 from "./joanna-kosinska-qcqmS0JG58Q-unsplash.jpg";
import StillLife4 from "./masha-rostovskaya-Cngzg6CiEU8-unsplash.jpg";

export { StillLife1, StillLife2, StillLife3, StillLife4 };
