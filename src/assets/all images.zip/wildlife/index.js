﻿import Wildlife1 from "./Rectangle 25 (1).png";
import Wildlife2 from "./Rectangle 25 (2).png";
import Wildlife3 from "./Rectangle 25.png";
import Wildlife4 from "./zdenek-machacek-UxHol6SwLyM-unsplash.jpg";

export {
    Wildlife1,
    Wildlife2,
    Wildlife3,
    Wildlife4,
};
