﻿import Creative1 from "./centre-for-ageing-better-hkHXc7J6VXM-unsplash.jpg";
import Creative2 from "./rachael-gorjestani-X6CZGpJBi8U-unsplash.jpg";
import Creative3 from "./skye-studios-NDLLFxTELrU-unsplash.jpg";
import Creative4 from "./tim-arterbury-VkwRmha1_tI-unsplash.jpg";

export { Creative1, Creative2, Creative3, Creative4 };