﻿import Macro1 from "./dan-carlson-G86MS2ZsiJA-unsplash.jpg";
import Macro2 from "./gildardo-rh-q1-dAZuhs7I-unsplash.jpg";
import Macro3 from "./jill-heyer-U9x5mG0pBiQ-unsplash.jpg";
import Macro4 from "./mister-starman-ZzpD01gzjrI-unsplash.jpg";

export { Macro1, Macro2, Macro3, Macro4 };
