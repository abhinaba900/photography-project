﻿import People1 from "./christopher-campbell-rDEOVtE7vOs-unsplash.jpg";
import People2 from "./nathan-anderson-FHiJWoBodrs-unsplash.jpg";
import People3 from "./priscilla-du-preez-XkKCui44iM0-unsplash.jpg";
import People4 from "./priscilla-du-preez-nF8xhLMmg0c-unsplash.jpg";

export { People1, People2, People3, People4 };